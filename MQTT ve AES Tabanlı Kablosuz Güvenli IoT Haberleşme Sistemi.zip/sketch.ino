// ===============================
// LED'in bağlı olduğu pin (ESP32)
// ===============================
const int LED_PIN = 26;

// ==========================================
// Basit XOR şifreleme / çözme fonksiyonu
// ==========================================
String encryptDecrypt(String data) {

  char key = 'K';         // Şifreleme anahtarı (tek karakter)
  String result = "";     // Sonuç verisini tutacak değişken

  // Veri içindeki her karakter için döngü
  for (int i = 0; i < data.length(); i++) {

    // XOR işlemi yapılır
    // data[i] ^ key → karakter dönüşür
    result += char(data[i] ^ key);
  }

  // Şifrelenmiş (veya çözülmüş) veri döndürülür
  return result;
}

// ==========================================
// setup() → sadece 1 kez çalışır
// ==========================================
void setup() {

  Serial.begin(115200);          // Serial monitor başlatılır
  pinMode(LED_PIN, OUTPUT);      // LED pini çıkış yapılır

  Serial.println("Sistem basladi"); // Başlangıç mesajı
}

// ==========================================
// loop() → sürekli tekrar eder
// ==========================================
void loop() {

  // =========================
  // 1️⃣ Düz veri oluşturma
  // =========================
  String data = "sicaklik=25";   // Gönderilecek veri

  Serial.print("Duz veri: ");
  Serial.println(data);          // Ekrana yazdır

  // =========================
  // 2️⃣ Veriyi şifreleme
  // =========================
  String encrypted = encryptDecrypt(data);

  Serial.print("Sifreli veri: ");
  Serial.println(encrypted);     // Şifreli hali (garip karakterler normal)

  // =========================
  // 3️⃣ Şifreyi çözme
  // =========================
  String decrypted = encryptDecrypt(encrypted);

  Serial.print("Cozulmus veri: ");
  Serial.println(decrypted);     // Tekrar orijinal veri

  // =========================
  // 4️⃣ Komut simülasyonu
  // =========================
  // "ON" komutu önce şifreleniyor, sonra çözülüyor
  // (Gerçekte bu MQTT'den gelmiş gibi düşün)
  String cmd = encryptDecrypt(encryptDecrypt("ON"));

  // =========================
  // 5️⃣ Komuta göre LED kontrol
  // =========================
  if (cmd == "ON") {

    digitalWrite(LED_PIN, HIGH);   // LED yak
    Serial.println("LED ACILDI");  // Bilgi mesajı
  }

  // =========================
  // 6️⃣ Bekleme
  // =========================
  delay(3000);   // 3 saniye bekle (sonra tekrar başlar)
}