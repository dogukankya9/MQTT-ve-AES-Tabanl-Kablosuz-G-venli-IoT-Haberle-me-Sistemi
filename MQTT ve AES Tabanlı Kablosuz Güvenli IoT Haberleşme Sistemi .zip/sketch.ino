#include <WiFi.h>              // ESP32 WiFi bağlantısı
#include <PubSubClient.h>      // MQTT haberleşmesi
#include "mbedtls/aes.h"       // AES işlemleri

// ==========================
// WiFi ve MQTT ayarları
// ==========================
const char* ssid = "Wokwi-GUEST";                 // Wokwi WiFi adı
const char* password = "";                        // Wokwi şifresi boş
const char* mqtt_server = "broker.hivemq.com";   // MQTT broker
const char* topic = "dogukan/proje/ledkontrol";  // Dinlenecek topic

const int ledPin = 26;   // LED'in bağlı olduğu pin

// MQTT için nesneler
WiFiClient espClient;
PubSubClient client(espClient);

// ==========================
// AES anahtarı (16 byte = 128 bit)
// ==========================
unsigned char aes_key[16] = {
  'K','I','R','I','K','K','A','L',
  'E','_','U','N','I','_','1','6'
};

// ==========================
// Tek bir HEX karakterini sayıya çevirir
// Örnek: 'A' -> 10
// ==========================
byte charToHex(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return 0;
}

// ==========================
// 32 karakterlik HEX metni
// 16 byte'lık diziye çevirir
// ==========================
void hexToBytes(const char* hex, unsigned char* bytes) {
  for (int i = 0; i < 16; i++) {
    bytes[i] = (charToHex(hex[2 * i]) << 4) | charToHex(hex[2 * i + 1]);
  }
}

// ==========================
// Düz metni AES ile şifreler
// ve sonucu HEX olarak ekrana yazar
// Bu sayede telefondan hangi payload'ı göndereceğini görürsün
// ==========================
void printEncryptedHex(const char* message) {
  unsigned char plainText[16] = {0};   // 16 byte blok
  strcpy((char*)plainText, message);   // "ON" veya "OFF" içine kopyalanır

  unsigned char cipherText[16];        // şifreli veri burada tutulacak

  mbedtls_aes_context aes;
  mbedtls_aes_init(&aes);

  // AES şifreleme anahtarı ayarlanır
  mbedtls_aes_setkey_enc(&aes, aes_key, 128);

  // ECB modunda şifreleme yapılır
  mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, plainText, cipherText);

  mbedtls_aes_free(&aes);

  // Sonucu HEX olarak serial monitöre yaz
  Serial.print("Telefonda '");
  Serial.print(message);
  Serial.print("' komutu icin PAYLOAD kutusuna sunu yaz: ");

  for (int i = 0; i < 16; i++) {
    if (cipherText[i] < 16) Serial.print("0");   // tek haneli ise başına 0 koy
    Serial.print(cipherText[i], HEX);
  }

  Serial.println();
}

// ==========================
// MQTT'den veri gelince çalışır
// ==========================
void callback(char* topic, byte* payload, unsigned int length) {
  Serial.println("\n--- SIFRELI MESAJ ALINDI ---");

  // Gelen payload'ı string haline getir
  char hexStr[33];
  int safeLen = (length < 32) ? length : 32;

  for (int i = 0; i < safeLen; i++) {
    hexStr[i] = (char)payload[i];
    Serial.print((char)payload[i]);
  }
  hexStr[safeLen] = '\0';

  Serial.println(" (Internetten gelen sifreli veri)");

  // 1) HEX metni byte dizisine çevir
  unsigned char cipherText[16];
  hexToBytes(hexStr, cipherText);

  // 2) AES ile çöz
  unsigned char plainText[16] = {0};

  mbedtls_aes_context aes;
  mbedtls_aes_init(&aes);

  mbedtls_aes_setkey_dec(&aes, aes_key, 128);
  mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_DECRYPT, cipherText, plainText);

  mbedtls_aes_free(&aes);

  // 3) Çözülen veriyi string'e çevir
  String decryptedMessage = String((char*)plainText);

  Serial.print("Sifre Cozuldu! Komut: ");
  Serial.println(decryptedMessage);

  // 4) Komuta göre LED kontrolü
  if (decryptedMessage.startsWith("ON")) {
    digitalWrite(ledPin, HIGH);
    Serial.println("LED ACILDI");
  } 
  else if (decryptedMessage.startsWith("OFF")) {
    digitalWrite(ledPin, LOW);
    Serial.println("LED KAPANDI");
  } 
  else {
    Serial.println("Gecersiz komut veya hatali sifre!");
  }
}

// ==========================
// MQTT tekrar bağlanma
// ==========================
void reconnect() {
  while (!client.connected()) {
    Serial.print("MQTT baglaniliyor... ");

    String clientId = "ESP32Client-";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("Baglandi!");
      client.subscribe(topic);
      Serial.print("Subscribe edilen topic: ");
      Serial.println(topic);
    } else {
      Serial.print("Hata kodu: ");
      Serial.println(client.state());
      delay(5000);
    }
  }
}

// ==========================
// setup()
// ==========================
void setup() {
  Serial.begin(115200);
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);   // başlangıçta LED kapalı

  // WiFi bağlantısı
  WiFi.begin(ssid, password);
  Serial.print("WiFi baglaniliyor");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Baglandi!");

  // Telefon uygulamasında kullanacağın şifreli payload'ları yazdır
  Serial.println("\n--- TELEFON UYGULAMASI ICIN SIFRELER ---");
  printEncryptedHex("ON");
  printEncryptedHex("OFF");
  Serial.println("----------------------------------------\n");

  // MQTT ayarı
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
}

// ==========================
// loop()
// ==========================
void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}